# LeNet
import tensorflow as tf

input_size, output_size = 784, 10
image_size, channels = 32, 3
layer1_size, layer1_deep = 5, 32
layer2_size, layer2_deep = 5, 64
fc_size = 512


def forward_propagation(X, train, regularizer):
    with tf.variable_scope('layer1_conv1'):
        conv1_weights = tf.get_variable('weight', [layer1_size, layer1_size, channels, layer1_deep],
                                        initializer=tf.truncated_normal_initializer(stddev=0.01))
        conv1_biases = tf.get_variable('biases', [layer1_deep], initializer=tf.constant_initializer(0.0))

        conv1 = tf.nn.conv2d(X, conv1_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu1 = tf.nn.relu(tf.nn.bias_add(conv1, conv1_biases))

    with tf.name_scope('layer2_pool1'):
        pool1 = tf.nn.max_pool(relu1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

    with tf.variable_scope('layer3_conv2'):
        conv2_weights = tf.get_variable('weight', [layer2_size, layer2_size, layer1_deep, layer2_deep],
                                        initializer=tf.truncated_normal_initializer(stddev=0.01))
        conv2_biases = tf.get_variable('biases', [layer2_deep], initializer=tf.constant_initializer(0.0))

        conv2 = tf.nn.conv2d(pool1, conv2_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu2 = tf.nn.relu(tf.nn.bias_add(conv2, conv2_biases))

    with tf.name_scope('layer4_pool2'):
        pool2 = tf.nn.max_pool(relu2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

    pool_shape = pool2.get_shape().as_list()
    nodes = pool_shape[1] * pool_shape[2] * pool_shape[3]
    print('pool_shape[0]: ', pool_shape[0])
    print('nodes: ', nodes)
    # reshaped = tf.reshape(pool2, [pool_shape[0], nodes])
    reshaped=tf.layers.flatten(pool2)
    
    with tf.variable_scope('layer5_fc1'):
        fc1_weights = tf.get_variable('weight', [nodes, fc_size],
                                      initializer=tf.truncated_normal_initializer(stddev=0.01))
        # 只有全连接层的权重需要加入正则化
        if regularizer != None:
            tf.add_to_collection('losses', regularizer(fc1_weights))

        fc1_biases = tf.get_variable('bias', [fc_size], initializer=tf.constant_initializer(0.0))

        fc1 = tf.nn.relu(tf.matmul(reshaped, fc1_weights) + fc1_biases)

        if train:
            fc1 = tf.nn.dropout(fc1, 0.5)

    with tf.variable_scope('layer6_fc2'):
        fc2_weights = tf.get_variable('weight', [fc_size, output_size],
                                      initializer=tf.truncated_normal_initializer(stddev=0.01))

        if regularizer != None:
            tf.add_to_collection('losses', regularizer(fc2_weights))

        fc2_biases = tf.get_variable('bias', [output_size], initializer=tf.constant_initializer(0.0))

        logit = tf.matmul(fc1, fc2_weights) + fc2_biases

    return logit
