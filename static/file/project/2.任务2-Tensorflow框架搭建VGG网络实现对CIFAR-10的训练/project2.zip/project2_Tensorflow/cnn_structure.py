# LeNet
import tensorflow as tf

input_size, output_size = 784, 10
image_size, channels = 32, 3
layer1_size, layer1_deep = 3, 64
layer2_size, layer2_deep = 3, 128
layer3_size, layer3_deep = 3, 256
layer4_size, layer4_deep = 3, 512
fc1_size, fc2_size = 1024, 128
stddev = 0.03


def vgg_forward_propagation(X, train, regularizer):
    with tf.variable_scope('layer1_conv1'):
        conv1_1_weights = tf.get_variable('weight1', [3, 3, 3, layer1_deep],
                                        initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv1_1_biases = tf.get_variable('biases1', [layer1_deep], initializer=tf.constant_initializer(0.0))
        conv1_2_weights = tf.get_variable('weight2', [3, 3, layer1_deep, layer1_deep],
                                          initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv1_2_biases = tf.get_variable('biases2', [layer1_deep], initializer=tf.constant_initializer(0.0))

        conv1_1 = tf.nn.conv2d(X, conv1_1_weights, strides=[1, 1, 1, 1], padding='SAME')
        conv1_1 = tf.nn.bias_add(conv1_1, conv1_1_biases)
        conv1_2 = tf.nn.conv2d(conv1_1, conv1_2_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu1 = tf.nn.relu(tf.nn.bias_add(conv1_2, conv1_2_biases))

    with tf.name_scope('layer2_pool1'):
        pool1 = tf.nn.max_pool(relu1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

    with tf.variable_scope('layer3_conv2'):
        conv2_1_weights = tf.get_variable('weight1', [layer2_size, layer2_size, layer1_deep, layer2_deep],
                                        initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv2_1_biases = tf.get_variable('biases1', [layer2_deep], initializer=tf.constant_initializer(0.0))
        conv2_2_weights = tf.get_variable('weight2', [layer2_size, layer2_size, layer2_deep, layer2_deep],
                                          initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv2_2_biases = tf.get_variable('biases2', [layer2_deep], initializer=tf.constant_initializer(0.0))
        conv2_3_weights = tf.get_variable('weight3', [layer2_size, layer2_size, layer2_deep, layer2_deep],
                                          initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv2_3_biases = tf.get_variable('biases3', [layer2_deep], initializer=tf.constant_initializer(0.0))

        conv2_1 = tf.nn.conv2d(pool1, conv2_1_weights, strides=[1, 1, 1, 1], padding='SAME')
        conv2_1 = tf.nn.bias_add(conv2_1, conv2_1_biases)
        conv2_2 = tf.nn.conv2d(conv2_1, conv2_2_weights, strides=[1, 1, 1, 1], padding='SAME')
        conv2_2 = tf.nn.bias_add(conv2_2, conv2_2_biases)
        conv2_3 = tf.nn.conv2d(conv2_2, conv2_3_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu2 = tf.nn.relu(tf.nn.bias_add(conv2_3, conv2_3_biases))

    with tf.name_scope('layer4_pool2'):
        pool2 = tf.nn.max_pool(relu2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')


    with tf.variable_scope('layer5_conv3'):
        conv3_1_weights = tf.get_variable('weight1', [layer3_size, layer3_size, layer2_deep, layer3_deep],
                                        initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv3_1_biases = tf.get_variable('biases1', [layer3_deep], initializer=tf.constant_initializer(0.0))
        conv3_2_weights = tf.get_variable('weight2', [layer3_size, layer3_size, layer3_deep, layer3_deep],
                                          initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv3_2_biases = tf.get_variable('biases2', [layer3_deep], initializer=tf.constant_initializer(0.0))
        conv3_3_weights = tf.get_variable('weight3', [layer3_size, layer3_size, layer3_deep, layer4_deep],
                                          initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv3_3_biases = tf.get_variable('biases3', [layer4_deep], initializer=tf.constant_initializer(0.0))

        conv3_1 = tf.nn.conv2d(pool2, conv3_1_weights, strides=[1, 1, 1, 1], padding='SAME')
        conv3_1 = tf.nn.bias_add(conv3_1, conv3_1_biases)
        conv3_2 = tf.nn.conv2d(conv3_1, conv3_2_weights, strides=[1, 1, 1, 1], padding='SAME')
        conv3_2 = tf.nn.bias_add(conv3_2, conv3_2_biases)
        conv3_3 = tf.nn.conv2d(conv3_2, conv3_3_weights, strides=[1, 1, 1, 1], padding='SAME')
        relu3 = tf.nn.relu(tf.nn.bias_add(conv3_3, conv3_3_biases))

    with tf.name_scope('layer6_pool3'):
        pool3 = tf.nn.max_pool(relu3, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
        

    pool_shape = pool3.get_shape().as_list()
    nodes = pool_shape[1] * pool_shape[2] * pool_shape[3]
    # reshaped = tf.reshape(pool2, [pool_shape[0], nodes])
    reshaped = tf.layers.flatten(pool3)

    with tf.variable_scope('layer9_fc1'):
        fc1_weights = tf.get_variable('weight', [nodes, fc1_size],
                                      initializer=tf.truncated_normal_initializer(stddev=stddev))
        # 只有全连接层的权重需要加入正则化
        if regularizer != None:
            tf.add_to_collection('losses', regularizer(fc1_weights))

        fc1_biases = tf.get_variable('bias', [fc1_size], initializer=tf.constant_initializer(0.0))

        fc1 = tf.nn.relu(tf.matmul(reshaped, fc1_weights) + fc1_biases)

        if train:
            fc1 = tf.nn.dropout(fc1, 0.5)

    with tf.variable_scope('layer10_fc2'):
        fc2_weights = tf.get_variable('weight', [fc1_size, fc2_size],
                                      initializer=tf.truncated_normal_initializer(stddev=stddev))
        # 只有全连接层的权重需要加入正则化
        if regularizer != None:
            tf.add_to_collection('losses', regularizer(fc2_weights))

        fc2_biases = tf.get_variable('bias', [fc2_size], initializer=tf.constant_initializer(0.0))

        fc2 = tf.nn.relu(tf.matmul(fc1, fc2_weights) + fc2_biases)

        if train:
            fc2 = tf.nn.dropout(fc2, 0.5)

    with tf.variable_scope('layer11_fc3'):
        fc3_weights = tf.get_variable('weight', [fc2_size, output_size],
                                      initializer=tf.truncated_normal_initializer(stddev=stddev))

        if regularizer != None:
            tf.add_to_collection('losses', regularizer(fc3_weights))

        fc3_biases = tf.get_variable('bias', [output_size], initializer=tf.constant_initializer(0.0))

        logit = tf.matmul(fc2, fc3_weights) + fc3_biases

    return logit
