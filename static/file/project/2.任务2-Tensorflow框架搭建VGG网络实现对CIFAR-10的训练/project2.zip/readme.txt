这个项目主要实现了：利用华为云ModelArts平台的GPU，基于Tensorflow框架实现VGG网络并对CIFAR-10数据集进行分类，准确率为：82.5%
注意：由于是在华为云平台上的jupyter上训练的，部分ipynb代码与在本地的jupyter代码有差异，若想运行请仔细校对，并将数据集放入datasets文件夹下。
环境配置：
python：3.7
numpy：1.19.1
Tensorflow：1.8.0
