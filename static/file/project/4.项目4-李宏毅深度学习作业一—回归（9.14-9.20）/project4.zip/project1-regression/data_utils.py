import pandas as pd
import numpy as np
import csv

data_dir = 'datasets/'

def get_data(data_dir):
    train_data = pd.read_csv(data_dir + 'train.csv', encoding='big5') # 从csv文件读全部数据
    train_data = train_data.iloc[:, 3:]          # 去掉data前三列无效特征
    train_data[train_data == 'NR'] = 0           # 找出data中所有值为'NR'的表格，并置为0
    raw_train_data = train_data.to_numpy()       # 将data化为标准numpy数组格式: (4320, 27)
    
    test_data = pd.read_csv(data_dir + 'test.csv', header=None, encoding='big5')   # 处理test测试集步骤同上
    # print(test_data)
    test_data = test_data.iloc[:, 2:]
    test_data[test_data=='NR'] = 0
    raw_test_data = test_data.to_numpy()
    
    print('raw_train_data shape: ', raw_train_data.shape)
    print('raw_test_data shape: ', raw_test_data.shape)
    
    return raw_train_data, raw_test_data

def data_preprocessing(raw_train_data, raw_test_data):
    month_data = {}                             # 将初始数据按月份分开存入字典
    for month in range(12):
        sample = np.empty([18, 24 * 20])        # 每个月的数据均为：(特征数量, (24*20))
        for day in range(20):
            sample[:, day*24:(day+1)*24] = raw_train_data[18*(20*month+day):18*(20*month+day+1), :]
        month_data[month] = sample
    print('month_data[0] shape: ', month_data[0].shape)
    
    x_train = np.empty([12*471, 18*9], dtype=float) # 构建x_train，维度：(5652, 162)
    y_train = np.empty([12*471, 1], dtype=float)    # 构建y_train,维度：(5652, 1)
    for month in range(12):
        for day in range(20):
            for hour in range(24):
                if day == 19 and hour > 14:
                    continue
                x_train[month*471+day*24+hour, :] = month_data[month][:, day*24+hour : day*24+hour+9].reshape(1, -1)
                y_train[month*471+day*24+hour, 0] = month_data[month][9, day*24+hour+9]
    
    x_mean = np.mean(x_train, axis=0) # 18*9
    x_std = np.std(x_train, axis=0) # 18*9
    for i in range(len(x_train)):                        # x_train归一化
        for j in range(len(x_train[0])):
            if x_std[j] != 0:
                x_train[i][j] = (x_train[i][j] - x_mean[j]) / x_std[j]
        
    x_train = np.concatenate((np.ones([12*471, 1]), x_train), axis=1).astype(float) # 增加一维(bias)
    
    x_val, y_val = x_train[int(len(x_train) * 0.8):, :], y_train[int(len(y_train) * 0.8):, :]
    x_train, y_train = x_train[:int(len(x_train)*0.8), :], y_train[:int(len(y_train)*0.8), :]
    
    
    x_test = np.empty([240, 18*9], dtype=float)
    for i in range(240):
        x_test[i, :] = raw_test_data[18*i:18*(i+1), :].reshape(1, -1)
    for i in range(len(x_test)):
        for j in range(len(x_test[0])):
            if x_std[j] != 0:
                x_test[i][j] = (x_test[i][j] - x_mean[j]) / x_std[j]
    x_test = np.concatenate((np.ones([240, 1]), x_test), axis=1).astype(float)
    
    
    print('x_train shape: ', x_train.shape)
    print('y_train shape: ', y_train.shape)
    print('x_val shape: ', x_val.shape)
    print('y_val shape: ', y_val.shape)
    print('x_test shape: ', x_test.shape)
    return x_train, y_train, x_val, y_val, x_test

    
model_path = 'weight.npy'
def val_test(model_path, x_val, y_val):
    w = np.load(model_path)
    y_pred = np.dot(x_val, w)
    rmse = np.sqrt(np.sum(np.power(y_pred - y_val, 2)) / len(x_val)) # rmse
    print('In validation set: rmse = ', rmse)
    
def result_output(model_path, x_test):
    w = np.load(model_path)
    y_pred = np.dot(x_test, w)
    with open('outputs/submit.csv', mode='w', newline='') as submit_file:
        csv_writer = csv.writer(submit_file)
        header = ['id', 'value']
        # print(header)
        csv_writer.writerow(header)
        for i in range(240):
            row = ['id_' + str(i), y_pred[i][0]]
            csv_writer.writerow(row)
            # print(row)
    print('submission.csv file saved.')
    