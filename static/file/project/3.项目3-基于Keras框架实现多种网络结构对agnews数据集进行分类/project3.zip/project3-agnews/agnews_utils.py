import moxing as mox
mox.file.shift('os', 'mox')

import numpy as np
import csv
import os, sys
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils.np_utils import to_categorical
from keras import optimizers

def get_data(train_data_path, test_data_path):

    x_train, y_train = [], []
    x_test, y_test = [], []

    with open(train_data_path, 'r') as f:
        reader = csv.reader(f)
        for line in reader:
            y_train.append(line[0])
            x_train.append(str(line[1]) + '\\' + str(line[2]))
#         print('x_train length: ', len(x_train))
#         print('y_train length: ', len(y_train))
    f.close()

    with open(test_data_path, 'r') as f:
        reader = csv.reader(f)
        for line in reader:
            y_test.append(line[0])
            x_test.append(str(line[1]) + '//' + str(line[2]))
#         print('x_test length: ', len(x_test))
#         print('y_test length: ', len(y_test))
    f.close()

    print('Loading data complete.')
    return x_train, y_train, x_test, y_test


# Step2: Tokenize
'''
Tokenizer是一个用于向量化文本或将文本转换为序列的类。Tokenize实际上生成了一个字典，
并统计了词频等信息，没有把文本转成需要的向量表示
Tokenizer去掉了文本中除单引号"'"外的所有符号，只保留剩余文本，自动将大写换成小写
'''
def tokenizing(x_train, y_train, x_test, y_test, max_num_words, max_sequence_length):
#     print('Tokenizing...')

    x_all = x_train + x_test
#     print('x_all shape: ', len(x_all))

    tokenizer = Tokenizer(num_words=max_num_words)
    tokenizer.fit_on_texts(x_all)
    sequences = tokenizer.texts_to_sequences(x_all)

    word_index = tokenizer.word_index
    index_word = {v: k for k, v in word_index.items()}

#     print('Found %s unique tokens.' % len(word_index))

    x_train = sequences[:len(x_train)]
    x_test = sequences[len(x_train):]

    # 将类别4转换成类别0
    for i in range(len(y_train)):
        if y_train[i] == '4':
            y_train[i] = '0'
    for i in range(len(y_test)):
        if y_test[i] == '4':
            y_test[i] = '0'

    x_train = pad_sequences(x_train, maxlen=max_sequence_length)
    y_train = to_categorical(np.asarray(y_train))

    x_test = pad_sequences(x_test, maxlen=max_sequence_length)
    y_test = to_categorical(np.asarray(y_test))

    print('shape of x_train tensor: ', x_train.shape)
    print('shape of y_train tensor: ', y_train.shape)
    print('shape of x_test tensor: ', x_test.shape)
    print('shape of y_test tensor: ', y_test.shape)
    print('Tokenizing complete.')
    
    return word_index, x_train, y_train, x_test, y_test


def get_matrix(matrix_path, word_index, max_num_words, embedding_dim):
    embedding_dic = {}
    f = open(os.path.join(matrix_path), 'r', encoding='UTF-8')
    for line in f:
        values = line.split()
        word = values[0]
        embedding_dic[word] = np.asarray(values[1:], dtype='float32')
    f.close()

#     print('Found %s word vectors.' % len(embedding_dic))

    num_words = min(max_num_words, len(word_index))
    embedding_matrix = np.zeros((num_words + 1, embedding_dim))

    for word, i in word_index.items():
        if i > max_num_words:
            continue
        embedding_vector = embedding_dic.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector

    print('embedding_matrix shape: ', embedding_matrix.shape)
    return embedding_matrix


